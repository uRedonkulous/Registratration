README

README for Github Assignment