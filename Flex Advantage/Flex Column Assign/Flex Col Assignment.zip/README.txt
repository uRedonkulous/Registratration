README

README for flexible columns assignment